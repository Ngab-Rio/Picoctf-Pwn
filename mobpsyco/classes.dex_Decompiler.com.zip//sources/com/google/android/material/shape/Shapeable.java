package com.google.android.material.shape;

public interface Shapeable {
    ShapeAppearanceModel getShapeAppearanceModel();

    void setShapeAppearanceModel(ShapeAppearanceModel shapeAppearanceModel);
}
