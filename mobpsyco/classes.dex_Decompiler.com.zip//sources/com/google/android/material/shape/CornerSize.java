package com.google.android.material.shape;

import android.graphics.RectF;

public interface CornerSize {
    float getCornerSize(RectF rectF);
}
