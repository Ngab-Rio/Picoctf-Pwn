package com.google.android.material.expandable;

public interface ExpandableTransformationWidget extends ExpandableWidget {
    int getExpandedComponentIdHint();

    void setExpandedComponentIdHint(int i);
}
