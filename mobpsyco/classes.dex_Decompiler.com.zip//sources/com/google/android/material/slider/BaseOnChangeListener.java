package com.google.android.material.slider;

public interface BaseOnChangeListener<S> {
    void onValueChange(S s, float f, boolean z);
}
