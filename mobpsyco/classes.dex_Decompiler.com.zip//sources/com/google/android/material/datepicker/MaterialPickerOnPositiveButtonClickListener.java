package com.google.android.material.datepicker;

public interface MaterialPickerOnPositiveButtonClickListener<S> {
    void onPositiveButtonClick(S s);
}
