package androidx.core.util;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class Predicate$$ExternalSyntheticLambda2 implements Predicate {
    public final /* synthetic */ Object f$0;

    public /* synthetic */ Predicate$$ExternalSyntheticLambda2(Object obj) {
        this.f$0 = obj;
    }

    public final boolean test(Object obj) {
        return this.f$0.equals(obj);
    }
}
