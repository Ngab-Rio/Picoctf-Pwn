package androidx.core.app;

import android.app.Activity;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ActivityCompat$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ Activity f$0;

    public /* synthetic */ ActivityCompat$$ExternalSyntheticLambda0(Activity activity) {
        this.f$0 = activity;
    }

    public final void run() {
        ActivityCompat.lambda$recreate$0(this.f$0);
    }
}
