package androidx.lifecycle;

@Deprecated
public interface GenericLifecycleObserver extends LifecycleEventObserver {
}
